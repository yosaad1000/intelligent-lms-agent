# Intelligent LMS Architecture Guidelines

## Core Architecture Pattern
```
Student Upload → S3 → Bedrock KB (embeddings) → Bedrock Agent → Response
                ↓
Voice Interview → Transcribe → Profile Update → DynamoDB
                ↓
Doubt/Question → Bedrock LLM + KB → Solution → Chat History (DynamoDB)
                ↓
Performance Data → SageMaker → Intelligence Embedding → Feature Store
```

## Key AWS Services Stack
- **Authentication**: AWS Cognito (user pools for students/teachers)
- **Storage**: S3 (notes, files), DynamoDB (chat history, profiles)
- **Intelligence**: Bedrock (LLM, Knowledge Base, Agents), SageMaker (embeddings)
- **Voice**: Amazon Transcribe (speech-to-text)
- **APIs**: Lambda + API Gateway (microservices)
- **Security**: IAM roles, Cognito, API Gateway authorization

## Security Requirements
- AWS Cognito with MFA optional
- IAM least privilege policies
- S3 server-side encryption (SSE-S3)
- DynamoDB encryption at rest
- API Gateway rate limiting and CORS
- Secrets Manager for API keys
- CloudWatch logging (no PII)

## Development Approach
- Incremental deployment (9 steps)
- Build → Test → Improve → Next Step
- Each step fully tested before proceeding
- Security-first implementation