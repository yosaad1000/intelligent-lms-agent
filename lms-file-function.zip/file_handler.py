
import json
import boto3
import os
import uuid
from datetime import datetime
import hashlib

def lambda_handler(event, context):
    """Handle file uploads and process for RAG"""
    
    try:
        body = json.loads(event.get('body', '{}'))
        user_id = body.get('user_id', 'test-user')
        filename = body.get('filename', 'document.txt')
        content = body.get('content', '')
        
        if not content:
            return {
                'statusCode': 400,
                'headers': get_cors_headers(),
                'body': json.dumps({'error': 'Content is required'})
            }
        
        # Process file
        file_id = str(uuid.uuid4())
        
        # Store file metadata
        store_file_metadata(file_id, user_id, filename, content)
        
        # Process for RAG (create chunks and store)
        chunks = create_text_chunks(content)
        vectors_stored = store_document_vectors(file_id, user_id, filename, chunks)
        
        return {
            'statusCode': 200,
            'headers': get_cors_headers(),
            'body': json.dumps({
                'success': True,
                'file_id': file_id,
                'filename': filename,
                'chunks_created': len(chunks),
                'vectors_stored': vectors_stored,
                'processing_status': 'completed'
            })
        }
        
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': get_cors_headers(),
            'body': json.dumps({'error': str(e)})
        }

def create_text_chunks(text, chunk_size=300):
    """Create text chunks for RAG processing"""
    
    sentences = [s.strip() for s in text.split('.') if s.strip()]
    chunks = []
    current_chunk = ""
    
    for sentence in sentences:
        if len(current_chunk) + len(sentence) < chunk_size:
            current_chunk += sentence + ". "
        else:
            if current_chunk:
                chunks.append(current_chunk.strip())
            current_chunk = sentence + ". "
    
    if current_chunk:
        chunks.append(current_chunk.strip())
    
    return chunks

def store_file_metadata(file_id, user_id, filename, content):
    """Store file metadata in DynamoDB"""
    
    try:
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('lms-user-files')
        
        table.put_item(Item={
            'file_id': file_id,
            'user_id': user_id,
            'filename': filename,
            'content_preview': content[:200],
            'status': 'processed',
            'upload_timestamp': datetime.utcnow().isoformat(),
            'file_size': len(content)
        })
        
    except Exception as e:
        print(f"Error storing file metadata: {e}")

def store_document_vectors(file_id, user_id, filename, chunks):
    """Store document chunks for RAG retrieval"""
    
    try:
        # Store in DynamoDB as a simple vector store
        dynamodb = boto3.resource('dynamodb')
        
        # Create a simple vectors table if it doesn't exist
        try:
            table = dynamodb.Table('lms-document-vectors')
        except:
            # Table doesn't exist, create it
            dynamodb.create_table(
                TableName='lms-document-vectors',
                KeySchema=[
                    {'AttributeName': 'vector_id', 'KeyType': 'HASH'}
                ],
                AttributeDefinitions=[
                    {'AttributeName': 'vector_id', 'AttributeType': 'S'},
                    {'AttributeName': 'user_id', 'AttributeType': 'S'}
                ],
                GlobalSecondaryIndexes=[
                    {
                        'IndexName': 'user-id-index',
                        'KeySchema': [
                            {'AttributeName': 'user_id', 'KeyType': 'HASH'}
                        ],
                        'Projection': {'ProjectionType': 'ALL'}
                    }
                ],
                BillingMode='PAY_PER_REQUEST'
            )
            table = dynamodb.Table('lms-document-vectors')
        
        # Store each chunk
        vectors_stored = 0
        for i, chunk in enumerate(chunks):
            vector_id = f"{file_id}_chunk_{i}"
            
            # Create a simple "embedding" using hash for demo
            chunk_hash = hashlib.md5(chunk.encode()).hexdigest()
            
            table.put_item(Item={
                'vector_id': vector_id,
                'user_id': user_id,
                'file_id': file_id,
                'filename': filename,
                'chunk_index': i,
                'chunk_text': chunk,
                'chunk_hash': chunk_hash,
                'created_at': datetime.utcnow().isoformat()
            })
            
            vectors_stored += 1
        
        return vectors_stored
        
    except Exception as e:
        print(f"Error storing vectors: {e}")
        return 0

def get_cors_headers():
    """Get CORS headers"""
    return {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token'
    }
