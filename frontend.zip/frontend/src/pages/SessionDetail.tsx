import React from 'react';
import SessionDetailComponent from '../components/Session/SessionDetail';

const SessionDetailPage: React.FC = () => {
  return <SessionDetailComponent />;
};

export default SessionDetailPage;