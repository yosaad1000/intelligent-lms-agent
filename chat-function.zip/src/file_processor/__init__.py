"""
File Processor Microservice

Handles file upload, text extraction, and Knowledge Base integration
"""

__version__ = "1.0.0"